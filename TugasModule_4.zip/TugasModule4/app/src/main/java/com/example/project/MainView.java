package com.example.project;

public interface MainView {

    void checkPhoneNumber();
    void checkUrl();
    void checkLocation();
    void checkShareText();
}
